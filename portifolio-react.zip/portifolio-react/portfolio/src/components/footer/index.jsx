import styles from './Footer.module.css'

function Footer() {
    return (
        <footer className={styles.footer}>
            Feito por Lucas de Souza © 2024
        </footer>
    )
}

export default Footer