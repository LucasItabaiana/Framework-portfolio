import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Home from './pages/Home/'
import Sobre from '../src/pages/Home/sobre/index'
import Page404 from '../src/pages/Home/Page404/index'
import Contatos from '../src/pages/Home/Contatos/index'
import Paginabase from '../src/pages/Paginabase'
import Projetos from '../src/pages/Home/Projetos'

function AppRoutes() {
    return (
        <BrowserRouter>
            <Routes>
                <Route path='/' element={ <Paginabase /> }>
                <Route index element={ <Home /> }></Route>
                <Route path="/sobre" element={<Sobre />}></Route>
                <Route path="*" element={<Page404 />}></Route>
                <Route path="/contatos" element={ <Contatos /> }></Route>
                <Route path="/projetos" element={ <Projetos /> }></Route>
               </Route>
            </Routes>
        </BrowserRouter>
    )
}

export default AppRoutes